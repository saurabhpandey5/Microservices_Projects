package com.product.service;

import com.product.entity.Product;

public interface ProductService {
	
	public Product getProduct(Long id);

}
